# COVID-19-Info-Dashboard

1. Open project folder in VSCode and open a terminal.
2. Enter "pip install", installing 'requests' and maybe a few others I am forgetting.
3. Enter '$env:FLASK_APP = "COVID-19_Info_Dashboard"', referencing the python app file.
4. Enter '$env:FLASK_ENV = "development"'.
5. Enter 'flask run' to run the app, whose address (your local machine's) is linked in the terminal's output and openable in a broswer.
